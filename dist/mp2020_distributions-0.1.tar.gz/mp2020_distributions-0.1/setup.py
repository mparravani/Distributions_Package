from setuptools import setup

setup(name='mp2020_distributions',
      version='0.1',
      description='Gaussian and Binomial distributions',
      packages=['mp2020_distributions'],
      author = 'Michael Parravani',
      author_email = 'michael.parravani@gmail.com',
      zip_safe=False)
